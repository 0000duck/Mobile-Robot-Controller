#include"Common.h"
class Satellite
{
public:
	static Position RobotPosition;
	static void setPosition(int dx, int dy);
};