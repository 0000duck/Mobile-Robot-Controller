#pragma once
#include<stdio.h>
#include"sensor.h"
#include"movemanager.h"
#include"map.h"